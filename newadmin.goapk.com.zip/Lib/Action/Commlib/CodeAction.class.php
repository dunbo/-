<?php

class CodeAction extends CommonAction {

    function index(){
		$model = new Model();
		$database = $_GET['database'] ? $_GET['database'] : 'newgomarket';
		$table = $_GET['table'] ? $_GET['table'] : 'sj_soft';
		$res = $model -> query("SHOW FULL COLUMNS FROM {$database}.{$table}");
		
		if(!S('show_databases')){
			$show_databases = $model -> query("SHOW DATABASES");
			S('show_databases',$show_databases,180*24*60*60);
		}else{
			$show_databases = S('show_databases');
		}		
		$this->assign("database" , $database);
		$this->assign("show_databases" , $show_databases);
		//$this->assign("table_arr" , $table_arr);
		$this->display('form_designer');
    }
    
    function pub_get_tables(){
		$database = $_GET['database'] ;	
		$connect = D('Commlib.Code');
		$connect -> myConnect($database);
		$list = $connect -> query("SHOW TABLES like '%".$_GET['query']."%'");
	//	var_dump($list);
	//	echo $connect ->getlastsql();exit;
		$data = array(
			'query' => $_GET['query'],
			'suggestions' => array(),
		);
		foreach($list as $v){
			$data['suggestions'][] = $v['Tables_in_newgomarket '.'(%'.$_GET['query'].'%)'];
		}
		//var_dump($tables);exit;
		exit(json_encode($data));
    }
     
}
?>
