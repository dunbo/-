<?php 
class NameCertifyAction extends CommonAction{
    private $model;


    public function _initialize() {
        parent::_initialize();
        $this->model = D('Zhiyoo.Zhiyoo');
    }
    
    public function showSwitch(){
		
        $res = $this->model->table('zy_common_setting')->where(array('skey'=>'telswitch'))->find();
        $res1 = $this->model->table('zy_common_setting')->where(array('skey'=>'marketswitch'))->find();
 
        $this->assign('res',$res);
        $this->assign('res1',$res1);
        $this->display();
    }
    
    public function changeSwitch(){
        $tel = $_GET['tel'];
		$status = 0;
        $tips = '停用';
        if($_GET['status'] == 1){
            $status = 1;
            $tips = '开启';
        }
        
        $data = array('svalue'=>$status);
		if($tel == 'market'){
			$result = $this->model->table('zy_common_setting')->where("skey='marketswitch'")->save($data);
		}else{
			$result = $this->model->table('zy_common_setting')->where("skey='telswitch'")->save($data);
		}
        
        $this -> writelog("智友内容管理-实名认证-绑定手机开关 {$tips}绑定手机开关","zy_common_setting",$result,__ACTION__ ,"","edit");
        $this->success($tips.'成功');
    }
    




}