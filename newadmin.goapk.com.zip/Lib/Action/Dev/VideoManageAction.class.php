<?php

/**
 * 视频管理
 */

class VideoManageAction extends CommonAction {
    const HOST_TAG = "<!--{ANZHI_IMAGE_HOST}-->";
    private $true_table='soft_extra';      
    //视频列表
    public function video_list() {
        $model = M($this->true_table);
        $where = array();
        if (isset($_GET['s_package'])) {
            $where['package'] = trim($_GET['s_package']);
            $this->assign('package', trim($_GET['s_package']));
        }
        if(isset($_GET['check_status'])){
            $where['check_status'] = $_GET['check_status'];
            $this->assign('check_status',$_GET['check_status']);
        }else{
            $_GET['check_status'] = 0;
        }
        if (isset($_GET['s_softname'])) {
        	$softdata = $model->table('sj_soft')->where(array('softname'=>trim($_GET['s_softname']),'status'=>1,'hide'=>array('in',array(1,1024))))->field('package,softname')->select();
            // echo $model->getlastsql();
            $package_arr=array();
            foreach($softdata as $v){
                $package_arr[]=$v['package'];
            }
            $where['package'] = array('in',$package_arr);
            $this->assign('softname', trim($_GET['s_softname']));
        }
        if (isset($_GET['s_video_title'])) {
            $where['video_title'] = array('like',"%".trim($_GET['s_video_title']."%"));
            $this->assign('video_title', trim($_GET['s_video_title']));
        }
        if (isset($_GET['s_video_num'])) {
            $where['video_num'] = trim($_GET['s_video_num']);
            $this->assign('video_num', trim($_GET['s_video_num']));
        }
        
        $where['status'] = 1;
        $count = $model->where($where)->count();
        import("@.ORG.Page2");
        $pg=$_GET['p']?$_GET['p']:1;
        $this->assign('pg', $pg);
        $param = http_build_query($_GET);
        $Page = new Page($count, 10, $param);
        $this->assign('total', $count);
        $order = 'add_tm desc';
        $o_param = preg_replace('/order=[^&]{1,}/','',$param);
        $this->assign('o_param',$o_param);
        if(isset($_GET['order'])){

            if($_GET['order']=='a'){
              $order = 'add_tm asc';
            }else{
              $order = 'add_tm desc';
            }
            $this->assign('order',$_GET['order']);
        }

        $list = $model->where($where)->limit($Page->firstRow . ',' . $Page->listRows)->order($order)->select();
        $package=array();
        foreach($list as $k=>$v){
          $package[]=$v['package'];
        }
        
        $softdata=get_table_data(array('package'=>array('in',$package),'status'=>1,'hide'=>1),"sj_soft","package","*");
        foreach($list as $k=>$v){
          $list[$k]['softname']=$softdata[$v['package']]['softname'];
          if($v['video_num']==1){
            $list[$k]['source']='游戏联运';
          }else if($v['video_num']==2){
            $list[$k]['source']='开发者';
          }else if($v['video_num']==3){
            $list[$k]['source']='视频';
          }
          
        }
        $this->assign('list', $list);
        $this->assign('attachment_host', GAMEINFO_ATTACHMENT_HOST);
        $this->assign('page', $Page->show());
        $this->display();
    }
    //视频删除
    public function video_del() {
        $model = M($this->true_table);

        $data = array(
            'update_tm' => time(),
            'status' => 0,
            'id' => $_GET['id'],
        );
        $res = $model->save($data);
        if ($res) {
			$this->writelog("删除了此条视频，其中id为{$_GET['id']}。", 'sj_soft_extra', $_GET['id'], __ACTION__,"","del");
            $this->success("操作成功");
        }else{
            $this->success("操作失败");
        }
    }
    
    
    public function video_edit(){
    	$model = M($this->true_table);
        if($_GET['id']||$_GET['add']){
            if($_GET['id']){
                $video_data=$model->where(array('id'=>$_GET['id']))->find();
                $this->assign('attachment_host', GAMEINFO_ATTACHMENT_HOST);
                $soft_data=$model->table('sj_soft')->where(array('package'=>$video_data['package'],'status'=>1,'hide'=>array('in',array(1,1024))))->find();
                $video_data['softname']=$soft_data['softname'];
                $this->assign('video_data', $video_data);
            }
            if($_GET['show_video']==1){
                $this->display('video_show');
            }else{
                $this->display();
            }
            
        }else if($_POST){
            $data=array();
            $task_data=array();
            $data['id']=trim($_POST['id']);
            $data['video_num']=3;
            $data['status']=1;
            $data['video_type']=1;
            $data['video_title']=trim($_POST['video_title']);
            if($data['id']){
                $video_data=$model->where(array('id'=>$data['id']))->find();
                $data['update_tm']=time();
                $video_data_old=array('video_url'=>$video_data['video_url'],'video_pic'=>$video_data['video_pic'],'video_pic_30'=>$video_data['video_pic_30'],'video_pic_60'=>$video_data['video_pic_60']);
            	if(!$_FILES['video_url']['tmp_name']&&!$video_data['video_url']){
            		$this->error("请上传200M以内MP4格式视频");
            	}
            }else{
            	
            	$data['add_tm']=time();
            	if(!$_FILES['video_url']['tmp_name']){
            		$this->error("请上传200M以内MP4格式视频");
            	}

            }
            	$data['package']=trim($_POST['package']);
                $task_data['package']=trim($_POST['package']);

                $soft_data=$model->table('sj_soft')->where(array('package'=>$data['package'],'status'=>1,'hide'=>array('in',array(1,1024))))->find();
                $data['softid']=$soft_data['softid'];
                $task_data['softid']=$soft_data['softid'];
			  // `video_pic` varchar(255) DEFAULT '' COMMENT '视频图片',
			  // `video_url` varchar(255) NOT NULL DEFAULT '' COMMENT '视频路径',
			  // `video_md5` varchar(255) NOT NULL DEFAULT '' COMMENT '视频md5',
			  // `video_filesize` varchar(255) NOT NULL DEFAULT '' COMMENT '视频大小',
			 
			  // `video_pic_30` varchar(255) NOT NULL DEFAULT '' COMMENT '图片大小30k 宽度320',
			  // `video_pic_60` varchar(255) NOT NULL DEFAULT '' COMMENT '图片大小60k 宽度480',
			  // `screen_mode` tinyint(1) DEFAULT '0' COMMENT '1横屏 2竖屏',
			  // `video_h263_url` varchar(255) DEFAULT '' COMMENT '263编码视频路径',
            
            
            if($video_data_old){
            	$up_file=$this->upload_pic($video_data_old);
            }else{
            	$up_file=$this->upload_pic();
            }
            

            if(count($up_file)){
                // $file_path_arr=$this->upload_pic_do($up_file);
                // if($file_path_arr){
            	if($up_file['video_url']){
            		$task_data['url'] = $up_file['video_url'];
            	}
                $data=array_merge($data,$up_file);
                // }
            }
            //添加编辑成功还需要调work
            
            if($data['id']){
                $log = $this -> logcheck(array('id' => $data['id']),'sj_soft_extra',$data,$model);
                $re=$model->save($data);
                if($re){
                	$task_data['id']=$data['id'];
                	$this->create_h263_url($task_data);
                    $this->writelog('修改了视频id为'.$data["id"].'。'.$log, 'sj_soft_extra',$data["id"],__ACTION__ ,'','edit');
                    $check_status = isset($video_data['check_status'])?$video_data['check_status']:0;
                    $this->assign("jumpUrl",'/index.php/'.GROUP_NAME.'/VideoManage/video_list/check_status/'.$check_status);
                    $this->success('编辑成功');
                }else{
                    $this->error('编辑失败');
                }
            }else{

                $re=$model->add($data);
                if($re){
                	$task_data['id']=$re;
                	$this->create_h263_url($task_data);
                    $this->writelog('添加了一条视频，其中id为'.$re.'。', 'sj_soft_extra',$re,__ACTION__ ,'','add');
                    $this->assign("jumpUrl",'/index.php/'.GROUP_NAME.'/VideoManage/video_list/check_status/0');
                    $this->success('添加成功');
                }else{
                    $this->error('添加失败');
                }
            }
            
            
        }
    }
    public function upload_pic($data){
    	$fileicon=array();
    	if(!$_FILES){
    		return;
    	}
        foreach($_FILES as $key=>$val) {
        	$ext = strtolower(pathinfo($val['name'],PATHINFO_EXTENSION));
        	if($key=="video_pic"){
        		if(!$_FILES['video_pic']['tmp_name']){
        			continue;
        		}
				if(!in_array($ext,array('png','jpg'))) {
					$this->error('视频默认图：1256×706px，格式jpg、png');
				}else if(getimagesize($val['tmp_name'])===FALSE) {
					$this->error('视频默认图：1256×706px，格式jpg、png');
				}	
				$fileicon[$key] = '@'.$val['tmp_name'];
			}else if($key=="video_url"){
				if(!$_FILES['video_url']['tmp_name']){
        			continue;
        		}
				if($val['size'] > 200*1024*1024) {	//1M
					$this->error("请上传200M以内MP4格式视频");
				} else if(!in_array($ext,array('mp4'))) {
					$this->error('请上传200M以内MP4格式视频');
				}
				// else if(getimagesize($val['tmp_name'])===FALSE) {
				// 	$this->error('请上传1G以内MP4格式视频3');
				// }
				$fileicon['video'] = '@'.$val['tmp_name'];
			}
			
		}
		if($fileicon['video_pic']){
			$image_file = getimagesize(substr($fileicon['video_pic'],1));
			if($image_file[0] != 1256 || $image_file[1] != 706){
				$this->error("视频默认图：尺寸1256*706。支持JPG,PNG");
			}
		}
		$file_path=array();
        foreach($fileicon as $k=>$v){
        	if(!$v){
        		continue;
        	}
        	$file_path=array_merge($file_path,$this->upload_pic_do(array($k=>$v),$k));
        }
        // var_dump('调试');
        // var_dump($file_path);die;
        if($file_path){
        	if(!$file_path['video_pic']){
        		$file_path['video_pic'] = $data['video_pic'];
	            $file_path['video_pic_30'] = $data['video_pic_30'];
	            $file_path['video_pic_60'] = $data['video_pic_60'];
        	}
        	if(!$file_path['video_url']){
        		$file_path['video_url'] = $data['video_url'];
        	}
        	$video_data=$this->upload_pic_do($file_path,'video_backstage_handle');
        }
        
        // var_dump($video_data);die;
        return $video_data;
        
    }
    public function upload_pic_do($file,$k){
        if ($file) {
            $file['static_data'] = '/data/att/m.goapk.com';
            if($k=='video'){
            	$file['do'] = 'video';
            }else if($k=='video_pic'){
            	$file['do'] = 'video_pic';
            }else if($k=='video_backstage_handle'){
            	$file['do'] = 'video_backstage_handle';
            }
            
        }
        $upload_model = D("Dev.Uploadfile");
        $upload = $upload_model->_http_post($file);
        if ($upload['info']['http_code'] != 200) {
            $this->error("和图片服务器通讯失败，请重试！({$arr['errno']}:{$arr['error']})");
        }
        $pic_arr=array();
        // var_dump($upload['ret']['ret']);
        if ($upload['ret']['code']==1) {
            foreach ($upload['ret']['ret'] as $key => $val) {
    			if($key=='video'){
    				$val = str_replace('/data/att/m.goapk.com','',$val);
            		$pic_arr['video_url'] = $val;
            	}else{
            		$pic_arr[$key] = $val;
            	}
            }
        }else{
        	$this->error("{$upload['ret']['msg']}");
        }
        
        return $pic_arr;
    }
    public function pub_check_package() {
        $package = $_GET['package'];
        $find = $this->package_search($package);
        if ($find) {
            $this->ajaxReturn(1, $find, 1);
        } else {
            $this->ajaxReturn(0, '', 0);
        }
    }
    
    private function package_search($package) {
        if (!$package)
            return 0;
        $model = M();
        $where = array(
            'package' => $package,
            'status' => 1,
            'hide' => array('in', '1,1024'),
        );
        $find = $model->table('sj_soft')->where($where)->order('version_code')->order('version_code desc')->find();
        if ($find)
            return $find['softname'];
        return 0;            
    }
     function create_h263_url($task_data){
		$task_client = get_task_client();

		if($task_data['url']){
			$task_data['video_num']=3;
			$task_client->doBackground('video_change_format', json_encode($task_data));
		}
		
     }

    function change_status(){
        $id = $_GET['id'];
        $model = M('');
        $id = str_replace(",","','",$id);
        if(!$id){
            $this->error('缺少参数');
        }
        $where = array('id'=>array('exp', " in ('{$id}')"));
        $check_status = $_GET['check_status'];
        $res = $model->table('sj_soft_extra')->where($where)->save(array('check_status'=>$check_status,'update_tm'=>time()));
        $status_intro = array(0=>'撤销',1=>'通过',2=>'驳回');
        $now_status = $status_intro[$check_status];
        if($res){
            $this->writelog("{$now_status}了视频，ID为{$id}", 'sj_soft_extra', $id, __ACTION__,"","edit");
            $this->success("{$now_status}成功");
        }else{
            $this->error("{$now_status}失败");
        }
    }
 
}
