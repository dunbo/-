<?php
	class CoopwebsetAction extends CommonAction {
		//桌面预下载配置列表展示
		function webset_list() {
			echo 1;die;
		}
	}
?>

	