<?php

class ContentExplicitAction extends CommonAction {
    const HOST_TAG = "<!--{ANZHI_IMAGE_HOST}-->";

    //内容外显列表
    public function explicit_list() {
        $model = D('Sj.ContentExplicit');
        $where = array();
        if (isset($_GET['s_softid']) || isset($_GET['s_package'])) {
            $wheres = array('status' => 1);
            if (isset($_GET['s_softid'])) {
                $wheres['softid'] = trim($_GET['s_softid']);

                $this->assign('softid', $_GET['s_softid']);
            }
            if (isset($_GET['s_package'])) {
                $wheres['package'] = trim($_GET['s_package']);
                $this->assign('package', $_GET['s_package']);
            }
            $res = $model->table('sj_soft')->where($wheres)->field('package')->select();
            $package = array();
            foreach ($res as $v) {
                $package[] = $v['package'];
            }
            $where['package'] = array('in', $package);
        }
        if($_GET['s_show_style'] && $s_show_style = trim($_GET['s_show_style'])){
            $where['show_style'] = array('eq', $s_show_style);
            $this->assign("show_style", $s_show_style);
        }
        if($_GET['s_template_select'] && $s_template_select = trim($_GET['s_template_select'])){
            $where['template_select'] = array('eq', $s_template_select);
            $this->assign("template_select", $s_template_select);
        }
        if($_GET['s_content_type'] && $s_content_type = trim($_GET['s_content_type'])){
            $where['content_type'] = array('eq', $s_content_type);
            $this->assign("content_type", $s_content_type);
        }
        
        if($_GET['begintime'] && $begintime = strtotime(trim($_GET['begintime']))){
            $where["update_tm"] = array('egt', $begintime);
            $this->assign("begintime", $_GET['begintime']);
        }
        if($_GET['endtime'] && $endtime = strtotime(trim($_GET['endtime']))){
            $where["update_tm"] = array('elt', $endtime);
            $this->assign("endtime", $_GET['endtime']);
        }
        if($begintime && $endtime){
            $where["update_tm"] = array('exp', ">=$begintime and update_tm<=$endtime");
        }
        $where['status'] = 1;
        $passed=$_GET['passed']?$_GET['passed']:1;
        $t=time();
        if($passed==4){
           $where['end_tm'] = array('exp',"< {$t}"); 
           // $where['passed'] = 2; 
        }else{
           $where['passed'] = $passed; 
           // if($passed==2){
           //    $where['end_tm'] = array('exp',"> {$t}"); 
           // }
        }
        
        $this->assign('passed', $passed);

        $count = $model->where($where)->count();
        import("@.ORG.Page2");
        $pg=$_GET['p']?$_GET['p']:1;
        $this->assign('pg', $pg);
        $param = http_build_query($_GET);
        $Page = new Page($count, 10, $param);
        $this->assign('total', $count);
        if($passed==3){
            $list = $model->where($where)->limit($Page->firstRow . ',' . $Page->listRows)->order('update_tm desc')->select();
        }else{
            $list = $model->where($where)->limit($Page->firstRow . ',' . $Page->listRows)->order('update_tm desc')->select();
        }
        
       
        $dev_id=array();
        $package=array();

        
        foreach($list as $k=>$v){
          
          $list[$k]['create_tm']=date('Y-m-d H:i:s',$v['create_tm']);
          $list[$k]['update_tm']=date('Y-m-d H:i:s',$v['update_tm']);
          $list[$k]['start_tm']=date('Y-m-d H:i:s',$v['start_tm']);
          $list[$k]['end_tm']=date('Y-m-d H:i:s',$v['end_tm']);
          $dev_id[]=$v['dev_id'];
          $package[]=$v['package'];

        }

        $dev_list=get_table_data(array('dev_id'=>array('in',$dev_id)),"pu_developer","dev_id","*");
        
        $softdata = $model->table('sj_soft_tmp')->where(array('package'=>array('in',$package),'status'=>array('in',array(1,2)),'record_type'=>array('in',array(1,3))))->order('id desc')->select();
        $soft_list=array();
        $category=array();
        $softid=array();
        foreach($softdata as $v){
          $category[]=trim($v['category_id'],',');

          
          if(!$soft_list[$v['package']]){
            $soft_list[$v['package']]=$v;
            $softid[]=$v['id'];
          }
          
          
        }
        $category_list=array();
        // $category_list=get_table_data(array('category_id'=>array('in',$category)),"sj_category","category_id","category_id,name");
        foreach($category as $v){
            $category_list[$v]=$this->get_category($v);
        }

        $icon_list = get_table_data(array('tmp_id' => array('in',$softid)),"sj_soft_file_tmp","tmp_id","tmp_id,iconurl");
        
        $this->assign('icon_list', $icon_list);

        $this->assign('list', $list);
        $this->assign('dev_list', $dev_list);
        $this->assign('soft_list', $soft_list);
        $this->assign('category_list', $category_list);
        
        
     

        $this->assign('attachment_host', GAMEINFO_ATTACHMENT_HOST);

        $this->assign('page', $Page->show());
        $this->display();
    }
    //内容外显 过期删除 驳回 撤销 通过
    public function explicit_handle() {
        $model = D('Sj.ContentExplicit');
        $msg = $_POST['reject_reason'];
        $url_source = $_POST['url_source']?$_POST['url_source']:$_GET['url_source'];
        $passed = $_POST['passed']?$_POST['passed']:$_GET['passed'];
        //passed=4  为删除
        
        if($_GET['bs']==1 && $passed!=5){
             $this->assign('passed', $passed);
             $this->assign('id', $_GET['id']);
             $this->assign('url_source', $url_source);
             $this->display();
        }else{
            if (!$msg && $passed==3){
              $this->error("驳回原因不能为空");
            }
            
        }
        $id_arr = explode(',', $_POST['id']?$_POST['id']:$_GET['id']);
        $where = array(
            'id' => array('in', $id_arr),
        );
        $data = array(
            'update_tm' => time(),
            'passed' =>$passed,
        );
        if($passed==5){//通过并同步操作
            $data['passed'] = 2;
            $explicit_data  = $model->where(array('id'=>$_GET['id']))->find();
            $option['title'] = $explicit_data['title'];
            $option['package_name'] = $explicit_data['softname'];
            $option['package_643'] = $explicit_data['package'];
            $option['is_dev'] = 1;
            $rcontent=ContentTypeModel::saveRecommendContent(array('content_type'=>9,'used_id'=>$_GET['id']),'',$option);
            if($rcontent !==true){
                $this -> error($rcontent);
            }
            // 创建时间和更新时间
            $option['update_at'] = time();
            
            //获取区间
            $sql_extent = "SELECT extent_id FROM sj_flexible_extent where belong_page_type='fixed_resource_channel' and `status`=1 and extent_type IN(24,26) ORDER BY extent_type asc";
            $list_extent = M('')->query($sql_extent);
            $show_style = trim($_GET['show_style']);
            if($show_style==1 || $show_style==2){
            	$option['extent_id'] = $list_extent[0]['extent_id'];
            	$sql = "SELECT b.* FROM sj_flexible_extent as a INNER JOIN sj_flexible_extent_soft as b on a.extent_id = b.extent_id WHERE a.belong_page_type= 'fixed_resource_channel' and a.status=1 and b.resource_type= 24 and b.status = 1 and b.package_643 ='{$explicit_data['package']}' and b.content_type=9";
            	$dan_tu =  M('')->query($sql);
            	if(!isset($dan_tu[0]['id'])){
            		$ret = M('')->table('sj_flexible_extent_soft')->where(array('id'=>$dan_tu[0]['id']))->save($option);
            		if($ret){
            			$this->writelog('内容外显数据同步到灵活运营资源库单软件(列表单图)类型，其中资源库id为'.$dan_tu[0]['id'].'，内容外显id为'.$_GET['id'].'。', 'sj_flexible_extent',$dan_tu[0]['id'],__ACTION__ ,'','edit');
            		}
            	}else{
            		$option['create_at'] = time();
            		$option['resource_type'] = 24;
            		$affect = M('')->table('sj_flexible_extent_soft')->add($option);
            		if($affect){
            			$this->writelog('内容外显数据同步到灵活运营资源库单软件(列表单图)类型，其中资源库id为'.$affect.'，内容外显id为'.$_GET['id'].'。', 'sj_flexible_extent',$affect,__ACTION__ ,'','add');
            		}
            	}
//             	$dan_tu = M('')->table('sj_common_jump')->where(array('status'=>1,'content_type'=>9,'package_643'=>$explicit_data['package'],'resource_type'=>1))->field('id')->find();
//                 if(!empty($dan_tu['id'])){
//                     $ret = M('sj_common_jump')->table('sj_common_jump')->where(array('id'=>$dan_tu['id']))->save($option);
//                     if($ret){
//                         $this->writelog('内容外显数据同步到灵活运营资源库单软件(列表单图)类型，其中资源库id为'.$dan_tu['id'].'，内容外显id为'.$_GET['id'].'。', 'sj_common_jump',$dan_tu['id'],__ACTION__ ,'','edit');
//                     }
//                 }else{
//                     $option['create_at'] = time();
//                     $option['resource_type'] = 1;
//                     $affect = M('sj_common_jump')->table('sj_common_jump')->add($option);
//                     if($affect){
//                         $this->writelog('内容外显数据同步到灵活运营资源库单软件(列表单图)类型，其中资源库id为'.$affect.'，内容外显id为'.$_GET['id'].'。', 'sj_common_jump',$affect,__ACTION__ ,'','add');
//                     }
//                 }
            }
            if($show_style==2){
            	$option['extent_id'] = $list_extent[1]['extent_id'];
            	$sql_2 = "SELECT b.* FROM sj_flexible_extent as a INNER JOIN sj_flexible_extent_soft as b on a.extent_id = b.extent_id WHERE a.belong_page_type= 'fixed_resource_channel' and b.resource_type= 26 and a.status=1 and b.package_643 ='{$explicit_data['package']}' and b.status = 1 and b.content_type=9";
            	$duo_tu =  M('')->query($sql_2);
            	//$duo_tu = M('')->table('sj_common_jump')->where(array('status'=>1,'content_type'=>9,'package_643'=>$explicit_data['package'],'resource_type'=>2))->field('id')->find();
            	if(isset($duo_tu[0]['id'])){
            		$ret = M('')->table('sj_flexible_extent_soft')->where(array('id'=>$duo_tu[0]['id']))->save($option);
            		if($ret){
            			$this->writelog('内容外显数据同步到灵活运营资源库单软件(三图)类型，其中资源库id为'.$duo_tu[0]['id'].'，内容外显id为'.$_GET['id'].'。', 'sj_flexible_extent',$duo_tu[0]['id'],__ACTION__ ,'','edit');
            		}
            	}else{
            		$option['create_at'] = time();
            		$option['resource_type'] = 26;
            		$affect = M('')->table('sj_flexible_extent_soft')->add($option);
            		if($affect){
            			$this->writelog('内容外显数据同步到灵活运营资源库单软件(三图)类型，其中资源库id为'.$affect.'，内容外显id为'.$_GET['id'].'。', 'sj_flexible_extent',$affect,__ACTION__ ,'','add');
            		}
            	}
//                 $duo_tu = M('')->table('sj_common_jump')->where(array('status'=>1,'content_type'=>9,'package_643'=>$explicit_data['package'],'resource_type'=>2))->field('id')->find();
//                 if(!empty($duo_tu['id'])){
//                     $ret = M('sj_common_jump')->table('sj_common_jump')->where(array('id'=>$duo_tu['id']))->save($option);
//                     if($ret){
//                         $this->writelog('内容外显数据同步到灵活运营资源库单软件(三图)类型，其中资源库id为'.$duo_tu['id'].'，内容外显id为'.$_GET['id'].'。', 'sj_common_jump',$duo_tu['id'],__ACTION__ ,'','edit');
//                     }
//                 }else{
//                     $option['create_at'] = time();
//                     $option['resource_type'] = 2;
//                     $affect = M('sj_common_jump')->table('sj_common_jump')->add($option);
//                     if($affect){
//                         $this->writelog('内容外显数据同步到灵活运营资源库单软件(三图)类型，其中资源库id为'.$affect.'，内容外显id为'.$_GET['id'].'。', 'sj_common_jump',$affect,__ACTION__ ,'','add');
//                     }
//                 }
            }
        }
        if($passed==3){
            $data['reject_reason'] =$msg;
        }else if($passed==4){
            $data['status'] =0;
            unset($data['passed']);
        }
        $list = $model->where($where)->field('package,title,id')->select();
        $res = $model->where($where)->save($data);
        if ($res) {
            foreach ($list as $k => $v) {
                if($passed==2){
                    $this->writelog("通过了此条内容外显到审核中，其中id为{$v['id']},标题名称为{$v['title']},包名为{$v['package']}。", 'sj_soft_content_explicit', $v['id'], __ACTION__,"","edit");
                }else if($passed==3){
                    $this->writelog("驳回了此条内容外显，其中id为{$v['id']},标题名称为{$v['title']},包名为{$v['package']}。驳回原因：{$msg}", 'sj_soft_content_explicit', $v['id'], __ACTION__,"","edit");
                }else if($passed==1){
                    $this->writelog("撤销了此条内容外显到审核中，其中id为{$v['id']},标题名称为{$v['title']},包名为{$v['package']}。", 'sj_soft_content_explicit', $v['id'], __ACTION__,"","edit");
                }else if($passed==4){
                    $this->writelog("删除了此条内容外显到审核中，其中id为{$v['id']},标题名称为{$v['title']},包名为{$v['package']}。", 'sj_soft_content_explicit', $v['id'], __ACTION__,"","del");
                }
                
            }
            if($url_source){
                $this->assign("jumpUrl",'/index.php/'.GROUP_NAME.'/ContentExplicit/explicit_list/passed/1&1/1');
            }
            $this->success("操作成功");
        }else{
            $this->success("操作失败");
        }
    }
    public function get_category($category_id){
        $category_data=get_table_data(array('category_id'=>$category_id),"sj_category","category_id","*");
        if($category_data[$category_id]['parentid']==0){
          return $category_data[$category_id]['name'];
        }else{
          return $this->get_category($category_data[$category_id]['parentid']);
        }
    }
    public function explicit_edit(){
        $model = D('Sj.ContentExplicit');
        if($_GET['id']||$_GET['add']){
            if($_GET['id']){
                $explicit_data=$model->where(array('id'=>$_GET['id']))->find();
                $explicit_data['start_tm']=$explicit_data['start_tm']?date('Y-m-d H:i:s',$explicit_data['start_tm']):'';
                $explicit_data['end_tm']=$explicit_data['end_tm']?date('Y-m-d H:i:s',$explicit_data['end_tm']):'';
                $explicit_data['az_style_content']=json_decode($explicit_data['az_style_content'],true);
                $explicit_data['explicit_pic']=json_decode($explicit_data['explicit_pic'],true);
                $this->assign('attachment_host', GAMEINFO_ATTACHMENT_HOST);
                $this->assign('explicit_data', $explicit_data);
                $this->assign('az_style_content', $explicit_data['az_style_content']);
                $this->assign('passed', $_GET['passed']);
                $soft_data=$model->table('sj_soft')->where(array('package'=>$explicit_data['package'],'status'=>1,'hide'=>1))->find();
                $category_id=trim($soft_data['category_id'],",");
                $this->assign('category_name', $this->get_category($category_id));
            }
            
            $this->display();
        }else if($_POST){
            $data=array();
            $data['id']=trim($_POST['id']);
            if($data['id']){
                $explicit_data_before=$model->where(array('id'=>$data['id']))->find();
                $az_style_content_before=json_decode($explicit_data_before['az_style_content'],true);
                $explicit_pic_before=json_decode($explicit_data_before['explicit_pic'],true);
                $data['passed']=$explicit_data_before['passed'];
            }else{
                $az_style_content_before=array();
                $explicit_pic_before=array();
                $data['package']=trim($_POST['package']);
                $soft_data=$model->table('sj_soft')->where(array('package'=>$data['package']))->find();
                $data['softname']=$soft_data['softname'];
                $data['dev_id']=$soft_data['dev_id'];
                $data['passed']=1;
               

            }
            

            if($_POST['start_tm']){
                $data['start_tm']=strtotime(trim($_POST['start_tm']));
            }
            if($_POST['end_tm']){
                $data['end_tm']=strtotime(trim($_POST['end_tm']));
            }
            
            // $where=array();
            // $where["start_tm"] = array('elt', $data['end_tm']);
            // $where["end_tm"] = array('egt', $data['start_tm']);
            // $where['id']=array('neq',$data['id']);
            // $where['status']=1;
            // $where['package']=$explicit_data_before['package'];
            
            // $re_data=$model->where($where)->find();
            // if($re_data){
            //     $this->error("包名为{$explicit_data_before['package']}的内容外显与id为{$re_data['id']}时间交叉。");
            // }
            $data['show_style']=trim($_POST['show_style']);
            
            $az_model_num_sub=$_POST['az_model_num_sub'];
            $data['template_select']=trim($_POST['template_select']);

            $up_file=array();
            if($az_model_num_sub>0 && $data['template_select']==1){
                for($az_num=1;$az_num<($az_model_num_sub+1);$az_num++){

                    $az_style_content_before['az_style_'.$az_num]['article']=trim($_POST['article'.$az_num]);
                    $az_style_content_before['az_style_'.$az_num]['deputy_show']=trim($_POST['deputy_show'.$az_num]);
                    $az_style_content_before['az_style_'.$az_num]['pic_pattern']=trim($_POST['pic_pattern'.$az_num]);

                    if(trim($_POST['deputy_show'.$az_num])==1){
                        $pic_pattern_image=$this->upload_pic($_FILES['pic_pattern_image'.$az_num],'pic_pattern_image'.$az_num,$az_num,trim($_POST['pic_pattern'.$az_num]));
                        $up_file=array_merge($up_file,$pic_pattern_image);
                        if(count($az_style_content_before['az_style_'.$az_num]['pic_pattern_image'])){
                            foreach($az_style_content_before['az_style_'.$az_num]['pic_pattern_image'] as $kkk=>$vvv){
                                  $len=strlen($kkk);
                                  if(substr($kkk,$len-1,1)>$az_style_content_before['az_style_'.$az_num]['pic_pattern']-1){
                                      unset($az_style_content_before['az_style_'.$az_num]['pic_pattern_image'][$kkk]);
                                  }
                                  
                            }
                        }
                    }else{
                        unset($az_style_content_before['az_style_'.$az_num]['pic_pattern']);
                        unset($az_style_content_before['az_style_'.$az_num]['pic_pattern_image']);
                    }
                    

                }
            }

            
            if($data['show_style']==1 || $data['show_style']==2){
                $show_style_img_num=($data['show_style']==1)?1:4;
                $explicit_pic=$this->upload_pic($_FILES['explicit_pic'],'explicit_pic',0,$show_style_img_num);
                $up_file=array_merge($up_file,$explicit_pic);
                if($explicit_pic_before){
                    foreach($explicit_pic_before as $kk=>$vv){

                        if(substr($kk,3,1)>$show_style_img_num-1){
                            unset($explicit_pic_before['pic'.substr($kk,3,1)]);
                        }
                    }
                }
            }

            if(count($up_file)){
                $file_path_arr=$this->upload_pic_do($up_file);
            }
            
            
                
            
            
            foreach($file_path_arr as $k=>$v){
                 if(substr($k,0,3)=='pic'){   
                    $explicit_pic_before[$k]=$v;
                 }else{
                    if($data['template_select']==1){
                        $az_num=(substr($k,5,1)=='p')?substr($k,4,1):substr($k,4,2);
                        if($az_num && $az_style_content_before['az_style_'.$az_num]['deputy_show']==1){
                            $az_style_content_before['az_style_'.$az_num]['pic_pattern_image'][$k]=$v;
                        }
                    }
                    
                 }
                 
            }

            $data['explicit_pic']=json_encode($explicit_pic_before);
            if($data['template_select']==1){
                $data['az_style_content']=json_encode($az_style_content_before);
                $data['h_five_link_url']='';
            }else{
                $data['h_five_link_url']=trim($_POST['h_five_link_url']);
                $data['az_style_content']='';
            }
            
            $data['content_type']=trim($_POST['content_type']);
            $data['title']=trim($_POST['title']);
            
            $data['bottom_download_pink']=trim($_POST['bottom_download_pink']);
            // echo "<pre>";var_dump($data);die;

            $data['update_tm']=time();
            if($data['id']){
                $log = $this -> logcheck(array('id' => $data['id']),'sj_soft_content_explicit',$data,$model);
                $re=$model->save($data);
                if($re){
                    $this->assign("jumpUrl",'/index.php/'.GROUP_NAME.'/ContentExplicit/explicit_list/passed/'.$_POST['passed'].'');
                    $this->writelog('修改了内容外显id为'.$data["id"].'。'.$log, 'sj_soft_content_explicit',$data["id"],__ACTION__ ,'','edit');
                    $this->success('编辑成功');
                }else{
                    $this->error('编辑失败');
                }
            }else{

                $data['create_tm']=time();
                $re=$model->add($data);
                if($re){
                    $this->assign("jumpUrl",'/index.php/'.GROUP_NAME.'/ContentExplicit/explicit_list/passed/1/'.'');
                    $this->writelog('添加了一条内容外显，其中id为'.$re.'。', 'sj_soft_content_explicit',$re,__ACTION__ ,'','add');
                    $this->success('添加成功');
                }else{
                    $this->error('添加失败');
                }
            }
            
            
        }
    }
    public function upload_pic($file_arr,$source_key,$text_n=0,$num){
        // parent::error('1111');
        $file = array();
        // var_dump($num);
        // echo "<pre>";var_dump($file_arr);
        // var_dump($source_key);
        if ($file_arr) {
            $i=0;
            foreach ($file_arr as $key => $val) {
                if($source_key=='explicit_pic'){
                    if($key=='size'){
                        foreach($val as $s_k=>$s_v){
                            if(($s_v>512000) && $s_k<$num){
                              // var_dump(123);die;
                                $pic_n=$s_k+1;
                                $this->error("外显图片第{$pic_n}张上传失败");
                            }else if($s_k>=$num){
                                unset($file_arr['tmp_name'][$s_k]);
                                continue;
                            }else if(!$s_v){
                                unset($file_arr['tmp_name'][$s_k]);
                                continue;
                            }
                        }
                    }
                }
                // else if($text_n){
                //     if($key=='size'){
                //         foreach($val as $s_k=>$s_v){
                //             if(($s_v>102400) && $s_k<$num){
                //                 $pic_n=$s_k+1;
                //                 $this->error("文章正文{$text_n}的第{$pic_n}张图片上传失败");
                //             }else if($s_k>=$num){
                //                 unset($file_arr['tmp_name'][$s_k]);
                //                 continue;
                //             }else if(!$s_v){
                //                 unset($file_arr['tmp_name'][$s_k]);
                //                 continue;
                //             }
                //         }
                //     }
                // }
                if($key=='error'){
                    foreach($val as $s_k=>$e_v){
                        // var_dump($e_v);
                        // var_dump($num);
                        // var_dump($s_k);
                        if($e_v==0&&$s_k<$num){
                            $i++;
                        }else{
                            // var_dump($file_arr['tmp_name'][$s_k]);
                            unset($file_arr['tmp_name'][$s_k]);
                            // var_dump($file_arr['tmp_name']);die;
                            continue;
                        }
                    }
                }
                
            }
            foreach ($file_arr as $key => $val) {
                if($key=='tmp_name'){

                    foreach($val as $e_k=>$e_v){
                        if($e_k<$num){
                            if($text_n){
                                $pic="text{$text_n}pic".$e_k;
                            }else{
                                $pic='pic'.$e_k;
                            }
                            
                            $file[$pic] = '@' . $e_v;
                            $image_file = getimagesize(substr($file[$pic],1));
                            if($source_key=='explicit_pic'){
                                $pic_n=($e_k+1);
                                if($_POST['show_style']==1){
                                  $true_w=464;
                                  $true_h=274;
                                }else if($_POST['show_style']==2){
                                  if($pic_n<2){
                                    $true_w=464;
                                    $true_h=274;
                                  }else{
                                    $true_w=160;
                                    $true_h=160;
                                  }
                                  
                                }
                                if($image_file[0] != $true_w || $image_file[1] != $true_h){
                                    $this->error("外显图片第{$pic_n}张上传失败,图片尺寸：{$true_w}×{$true_h}，小于500KB");
                                }
                            }
                            // else if($text_n){
                            //     $pic_n=($e_k+1);
                            //     if(trim($_POST['pic_pattern'.$text_n])==1){
                            //       $true_w=640;
                            //       $true_h=270;
                            //     }else if(trim($_POST['pic_pattern'.$text_n])==2){
                            //       $true_w=280;
                            //       $true_h=450;
                            //     }else if(trim($_POST['pic_pattern'.$text_n])==3){
                            //       if($pic_n<2){
                            //         $true_w=280;
                            //         $true_h=450;
                            //       }else{
                            //         $true_w=280;
                            //         $true_h=215;
                            //       }
                            //     }
                            //     if($image_file[0] != $true_w || $image_file[1] != $true_h){
                            //       $this->error("文章正文{$text_n}的图片第{$pic_n}张上传失败,图片尺寸：{$true_w}×{$true_h}，小于100KB");
                            //     }
                            // }
                        }
                        
                        
                    }
                }
            }
        }
        // var_dump($file);die;
        return $file;
        
    }
    public function upload_pic_do($file){
        if ($file) {
            $file['static_data'] = '/data/att/m.goapk.com';
            $file['do'] = 'save';
        }
        $upload_model = D("Dev.Uploadfile");
        $upload = $upload_model->_http_post($file);
        // echo "<pre>";var_dump($upload);die;
        if ($upload['info']['http_code'] != 200) {
            $this->error("和图片服务器通讯失败，请重试！({$arr['errno']}:{$arr['error']})");
        }
        $pic_arr=array();
        if ($upload['ret']) {
            foreach ($upload['ret'] as $key => $val) {
                if ($val == 'failed') {
                    continue;
                } else {
                    $pic_arr[$key] = $val;
                }
            }
        }
        if(count($pic_arr)!=(count($file)-2)){
            // if($source_key=='explicit_pic'){
            //   $this->error("外显图片上传失败");
            // }
            $this->error("和图片服务器通讯失败，请重试！({$arr['errno']}:{$arr['error']})");
        }
        
        return $pic_arr;
    }
    public function preview_content_explicit(){
        $model = D('Sj.ContentExplicit');
        if($_GET['id']){
            $data = $model->where(array('id'=>trim($_GET['id'])))->field('*')->find();
            $data['az_style_content']=json_decode($data['az_style_content'],true);
            $data['explicit_pic']=json_decode($data['explicit_pic'],true);
            $this->assign('attachment_host', GAMEINFO_ATTACHMENT_HOST);
            $data['create_tm']=date('Y-m-d',$data['create_tm']);
            $this->assign('data', $data);
            $soft_data_note = $model->table('sj_soft_note')->where(array('package'=>$data['package']))->field('*')->find();
            $this->assign('in_short', $soft_data_note['in_short']);
            // $soft_data = $model->table('sj_soft')->where(array('package'=>$data['package'],'status'=>1,'hide'=>1))->field('*')->find();
            $soft_data = $model->table('sj_soft')->where(array('package'=>$data['package']))->field('*')->find();

            $soft_data_file = $model->table('sj_soft_file')->where(array('softid'=>$soft_data['softid']))->field('*')->find();
            $this->assign('iconurl_72', $soft_data_file['iconurl_72']);
            $this->display();
        }else{
            $this->error("id不能为空");
        }
        
    }
    // 远程请求检查根据包名查找软件名
    public function pub_check_package() {
        $package = $_POST['package'];
        // var_dump($package);die;
        $find = $this->package_search($package);
        if ($find) {
            $this->ajaxReturn(1, $find, 1);
        } else {
            $this->ajaxReturn(0, '', 0);
        }
    }
    
    private function package_search($package) {
        if (!$package)
            return 0;
        $model = M();
        $where = array(
            'package' => $package,
            'status' => 1,
            'hide' => array('in', '1,1024'),
            // 'hide' => 1,
        );
        $find = $model->table('sj_soft')->where($where)->order('version_code')->order('version_code desc')->find();
        if ($find)
            return $find['softname'];
        return 0;            
    }
}