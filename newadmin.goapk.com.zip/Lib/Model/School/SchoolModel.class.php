<?php
class SchoolModel extends Model {
	//调整表前缀
     protected $trueTableName = 'pu_channel_first_state';
}
?>