<?php
class PmModel extends Model {
	//调整表前缀
     protected $trueTableName = 'partner_cid_message';
}
?>