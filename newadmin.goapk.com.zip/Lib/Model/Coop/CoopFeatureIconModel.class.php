<?php
class CoopFeatureIconModel extends Model {
     protected $trueTableName = 'pu_coop_feature_icon';
}