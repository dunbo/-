<?php
class CoopFeatureModel extends Model {
     protected $trueTableName = 'pu_coop_feature';
}