<?php
class PromotionModel extends Model {
     protected $trueTableName = 'pu_coop_promotion';
}
?>
