<?php
class ConfigModel extends Model {
     protected $trueTableName = 'pu_coop_config';
}
?>
