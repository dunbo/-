<?php
class UserModel extends Model {
     protected $trueTableName = 'pu_coop_user';
}
?>
