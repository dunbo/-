<?php
class CooperatorModel extends Model {
     protected $trueTableName = 'pu_coop_cooperator';
}
?>
