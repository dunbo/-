<?php

//排序模型
class RankModel extends Model {
	public function __construct($trueTableName){
	    if(!empty($trueTableName)){
		    $this->trueTableName = $trueTableName;
		}
		parent::__construct();
	}
}

?>