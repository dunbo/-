<?php
class AdminconfigModel extends Model {
     protected $trueTableName = 'cj_admin_config';
}
?>
