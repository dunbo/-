<?php
class SoftwarelistModel extends Model {
     protected $trueTableName = 'cj_software';
}
?>
