<?php
class UserconfigModel extends Model {
     protected $trueTableName = 'cj_user_config';
}
?>
