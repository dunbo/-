<?php
class NewsoftwarelistModel extends Model {
     protected $trueTableName = 'cj_new_sowftware';
}
?>
